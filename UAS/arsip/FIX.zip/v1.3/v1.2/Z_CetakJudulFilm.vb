﻿Public Class Z_CetakJudulFilm

    Private Sub Z_CetakJudulFilm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class